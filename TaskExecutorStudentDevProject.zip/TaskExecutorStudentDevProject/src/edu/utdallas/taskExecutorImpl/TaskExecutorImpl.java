package edu.utdallas.taskExecutorImpl;

import edu.utdallas.taskExecutor.Task;
import edu.utdallas.taskExecutor.TaskExecutor;

public class TaskExecutorImpl implements TaskExecutor
{

	public TaskExecutorImpl(int threadPoolSize)
	{
		// TODO Complete the implementation
	}
	
	@Override
	public void addTask(Task task)
	{
		// TODO Complete the implementation
	}

}
