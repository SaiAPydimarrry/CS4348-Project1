This is a starter project can be used by teams as the foundation of their 
TaskExecutor implementations. 

The 'src' directory has been populated with the interfaces described in the project 
placed into their required packages. Also included in this starter project is a the 
class TaskExecutorImpl that will be completed by the teams along with the blocking FIFO.    